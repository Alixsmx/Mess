1. npm install
2. npm start
3. Otworz http://localhost:3000

Dane (historia + zdjecia) zapisuja sie w folderze data/ - na hostingu zostaw go trwalego.
Inny folder: zmienna DATA_DIR. Port: PORT.
