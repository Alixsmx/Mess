const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const IMGDIR = path.join(DATA, 'img');
const DB = path.join(DATA, 'history.json');
const ROOMS = ['ogólny', 'losowy', 'pomoc'];
const MAX_IMG = 1024 * 1024;
const KEEP_MS = 60 * 864e5; // serwer trzyma wiadomości max 60 dni
const MAX_MSGS = 1000;
fs.mkdirSync(IMGDIR, { recursive: true });

let history = Object.fromEntries(ROOMS.map(r => [r, []]));
try { Object.assign(history, JSON.parse(fs.readFileSync(DB, 'utf8'))); } catch {}
ROOMS.forEach(r => Array.isArray(history[r]) || (history[r] = []));

let timer;
const save = () => {
  clearTimeout(timer);
  timer = setTimeout(() => {
    fs.writeFile(DB + '.tmp', JSON.stringify(history), e => !e && fs.rename(DB + '.tmp', DB, () => {}));
  }, 400);
};
const imgPath = id => path.join(IMGDIR, id + '.jpg');
const prune = () => {
  const lim = Date.now() - KEEP_MS;
  for (const r of ROOMS) {
    const h = history[r];
    while (h.length && (h[0].time < lim || h.length > MAX_MSGS)) {
      const m = h.shift();
      if (m.img) fs.unlink(imgPath(m.id), () => {});
    }
  }
  save();
};
prune();
setInterval(prune, 36e5).unref();

const read = f => fs.readFileSync(path.join(__dirname, 'public', f));
const page = read('index.html'), bg = read('bg.jpg');

const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  const m = /^\/img\/([a-f0-9]{16})$/.exec(url);
  if (m) {
    return fs.readFile(imgPath(m[1]), (e, b) => {
      if (e) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'image/jpeg', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, max-age=86400' });
      res.end(b);
    });
  }
  if (url === '/bg.jpg') {
    res.writeHead(200, { 'Content-Type': 'image/jpeg', 'Cache-Control': 'public, max-age=604800' });
    return res.end(bg);
  }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(page);
});
const wss = new WebSocketServer({ server, maxPayload: 1.6 * 1024 * 1024 });

const send = (ws, d) => ws.readyState === 1 && ws.send(JSON.stringify(d));
const inRoom = r => [...wss.clients].filter(c => c.name && c.room === r);
const broadcastUsers = () => {
  const users = [...wss.clients].filter(c => c.name).map(c => c.name);
  wss.clients.forEach(c => c.name && send(c, { t: 'users', users }));
};

wss.on('connection', ws => {
  ws.last = 0;
  ws.on('message', raw => {
    let d;
    try { d = JSON.parse(raw); } catch { return; }

    if (d.t === 'join' && !ws.name) {
      const name = String(d.name || '').trim().slice(0, 20);
      if (!name) return send(ws, { t: 'err', msg: 'Podaj nick.' });
      if ([...wss.clients].some(c => c.name === name)) return send(ws, { t: 'err', msg: 'Ten nick jest zajęty.' });
      ws.name = name; ws.room = ROOMS[0];
      send(ws, { t: 'init', me: name, rooms: ROOMS, room: ws.room, history: history[ws.room] });
      broadcastUsers();
      return;
    }
    if (!ws.name) return;

    if (d.t === 'room' && ROOMS.includes(d.room)) {
      ws.room = d.room;
      send(ws, { t: 'history', room: d.room, history: history[d.room] });
    } else if (d.t === 'msg') {
      const text = String(d.text || '').trim().slice(0, 1000);
      const now = Date.now();
      let img = false;
      if (now - ws.last < 300) return;
      const msg = { id: crypto.randomBytes(8).toString('hex'), name: ws.name, room: ws.room, text, time: now };
      if (typeof d.img === 'string' && d.img.startsWith('data:image/jpeg;base64,')) {
        const buf = Buffer.from(d.img.slice(23), 'base64');
        if (!buf.length || buf.length > MAX_IMG || buf[0] !== 0xff || buf[1] !== 0xd8) return;
        fs.writeFileSync(imgPath(msg.id), buf);
        msg.img = img = true;
        msg.once = !!d.once;
      }
      if (!text && !img) return;
      ws.last = now;
      history[ws.room].push(msg);
      save();
      inRoom(ws.room).forEach(c => send(c, { t: 'msg', msg }));
    } else if (d.t === 'del') {
      for (const r of ROOMS) {
        const m = history[r].find(x => x.id === d.id && x.name === ws.name);
        if (m) { m.del = true; save(); inRoom(r).forEach(c => send(c, { t: 'del', id: m.id })); break; }
      }
    } else if (d.t === 'typing') {
      inRoom(ws.room).forEach(c => c !== ws && send(c, { t: 'typing', name: ws.name }));
    }
  });
  ws.on('close', broadcastUsers);
});

server.listen(PORT, () => console.log(`Glass Messenger: http://localhost:${PORT}`));
