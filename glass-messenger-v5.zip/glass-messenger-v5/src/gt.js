(()=>{
if(window.__gt||!window.GT)return;window.__gt=1;
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
const el=(t,c,x,p)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;if(p)p.append(e);return e};
const vm=document.querySelector('meta[name=viewport]')||el('meta','',null,document.head);vm.name='viewport';vm.content='width=device-width,initial-scale=1';

/* ===== Liquid Glass ===== */
const V='--card-background,--card-background-flat,--surface-background,--web-wash,--wash,--comment-background,--messenger-card-background,--nav-bar-background,--nav-bar-background-gradient-wash,--secondary-button-background,--input-background';
el('style','',`
html,html[class]{color-scheme:dark;${V.split(',').map(v=>v+':rgba(255,255,255,.08)!important').join(';')};
--primary-text:#fff!important;--secondary-text:rgba(235,242,255,.75)!important;--primary-icon:#fff!important;--secondary-icon:rgba(235,242,255,.75)!important;--divider:rgba(255,255,255,.16)!important;--hover-overlay:rgba(255,255,255,.12)!important}
body{background:radial-gradient(60% 50% at 15% 10%,#3a7bff88,transparent),radial-gradient(50% 50% at 90% 85%,#b45cff77,transparent),linear-gradient(160deg,#07122b,#12285a) fixed!important}
[role=main],[role=navigation],[role=complementary],[role=banner]{backdrop-filter:blur(22px) saturate(1.9)!important;-webkit-backdrop-filter:blur(22px) saturate(1.9)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.4),0 12px 40px rgba(0,0,0,.28)!important;border-radius:22px}
.gt-f,.gt-p{position:fixed;z-index:2147483647;color:#fff;font:15px/1.4 system-ui,sans-serif;background:rgba(20,32,70,.55);backdrop-filter:blur(22px) saturate(1.9);-webkit-backdrop-filter:blur(22px) saturate(1.9);box-shadow:inset 0 1px 0 rgba(255,255,255,.5),0 10px 30px rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.25)}
.gt-s{position:fixed;left:50%;transform:translateX(-50%);bottom:24px;z-index:2147483647;color:#fff;font:600 15px system-ui,sans-serif;padding:13px 22px;border-radius:999px;border:1px solid rgba(255,255,255,.35);background:rgba(10,132,255,.6);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px)}
.gt-s[hidden]{display:none}
.gt-f{touch-action:none;right:10px;bottom:90px;width:46px;height:46px;border-radius:50%;font-size:20px;cursor:pointer}
.gt-p{inset:8% 6%;border-radius:30px;padding:18px;overflow:auto;display:flex;flex-direction:column;gap:10px}
.gt-p[hidden]{display:none}
.gt-p h3{margin:6px 0 0;font-size:16px}
.gt-b{color:#fff;font:inherit;padding:12px 16px;border-radius:999px;border:1px solid rgba(255,255,255,.3);background:rgba(255,255,255,.16);cursor:pointer}
.gt-r{padding:8px 12px;border-radius:16px;background:rgba(255,255,255,.08);overflow-wrap:anywhere}
.gt-d{color:#ff9aa8;padding:4px 12px;font-size:14px;overflow-wrap:anywhere}`,document.head);

/* ===== archiwum usuniętych ===== */
const DEL=/(unsent (a|this) message|usun[a-zęąłó]*\s+wiadomość|cofn[a-zęąłó]*\s+wysłanie\s+wiadomości|wiadomość (została )?(usunięta|cofnięta))\.?$/i;
let store=LS('gt_s',{}),del=LS('gt_d',[]),ph=new Set(LS('gt_p',[])),seen=new WeakMap(),tm,last=0,n=0;
const IMG='img[src*=fbcdn],img[src*=fbsbx]';
const txt=r=>{const a=[...r.querySelectorAll('[dir=auto]')].map(e=>e.innerText).join(' ').replace(/\s+/g,' ').trim();return a||([...r.querySelectorAll(IMG)].some(i=>i.naturalWidth>=150)?'[zdjęcie]':'')};
const isDel=t=>t.length<70&&DEL.test(t);
const line=d=>'['+d.time+'] '+d.c+' | '+d.w+' - '+d.t.replace(/\n/g,' ');
const flush=()=>{if(!GT.name('m'))return;let x=0;del.forEach(d=>{if(!d.f){d.f=1;x++;GT.text(line(d))}});if(x)sv('gt_d',del)};
function mark(r,o,c,w){
  r.prepend(el('div','gt-d','🗑 '+o+(o==='[zdjęcie]'?' (zapisane w folderze zdjęć)':'')));
  const k=c+'|'+w+'|'+o;
  if(!del.some(d=>d.k===k)){del.push({k,c:(document.querySelector('[role=main] h2')||{}).innerText||c,w,t:o,time:new Date().toLocaleString('pl'),f:0});if(del.length>1000)del.shift();sv('gt_d',del)}
}
function save(u,force){
  const k=u.split('?')[0];if(!force&&ph.has(k))return;
  ph.add(k);sv('gt_p',[...ph].slice(-3000));const f='fb_'+Date.now()+'_'+(++n)+'.jpg';
  if(/^https?:/.test(u))GT.url(u,f);
  else fetch(u).then(r=>r.blob()).then(b=>{const fr=new FileReader();fr.onload=()=>GT.b64(f,String(fr.result).split(',')[1]);fr.readAsDataURL(b)}).catch(()=>{});
}
const big=()=>[...document.querySelectorAll('[role=main] [role=row] img,[role=dialog] img')].filter(i=>i.naturalWidth>=200&&/fbcdn|fbsbx|^blob:/.test(i.src)&&!i.closest('.gt-p'));
function photos(){
  const b=big(),dl=b.filter(i=>i.closest('[role=dialog]'));
  sbtn.hidden=!dl.length;sbtn._u=dl.length?dl[dl.length-1].src:'';
  if(GT.name('p'))b.forEach(i=>save(i.src));
}
function scan(){
  const c=location.pathname,rs=[...document.querySelectorAll('[role=main] [role=row]')],T=rs.map(txt);
  rs.forEach((r,i)=>{
    const t=T[i];if(!t)return;
    const p=(T[i-1]||'').slice(0,40),q=(T[i+1]||'').slice(0,40),k=c+'\u0001'+p+'\u0001'+q;
    if(!isDel(t)){seen.set(r,t);store[k]=t;store[c+'\u0002'+p]=t;store[c+'\u0003'+q]=t}
    else if(!r.querySelector('.gt-d')){
      const o=seen.get(r)||store[k]||store[c+'\u0002'+p]||store[c+'\u0003'+q];
      if(o&&!isDel(o))mark(r,o,c,t);
    }
  });
  const ks=Object.keys(store);if(ks.length>6000)ks.slice(0,ks.length-6000).forEach(k=>delete store[k]);
  if(Date.now()-last>5000){last=Date.now();sv('gt_s',store)}
  flush();photos();
}
const sched=()=>{clearTimeout(tm);tm=setTimeout(scan,600)};
new MutationObserver(sched).observe(document.body,{childList:true,subtree:true,characterData:true});
document.addEventListener('load',e=>{if(e.target.tagName==='IMG')sched()},true);
document.addEventListener('visibilitychange',()=>sv('gt_s',store));
setInterval(scan,4000);setTimeout(scan,1500);

/* ===== kosz (przesuwany) i panel ===== */
const fab=el('button','gt-f','🗑',document.body),pan=el('div','gt-p',null,document.body),sbtn=el('button','gt-s','⬇ Zapisz zdjęcie',document.body);pan.hidden=sbtn.hidden=true;
sbtn.onclick=()=>{if(!GT.name('p')){pan.hidden=false;draw();return}save(sbtn._u,true);sbtn.textContent='✔ Zapisano';setTimeout(()=>sbtn.textContent='⬇ Zapisz zdjęcie',1500)};
const pos=LS('gt_pos',null);
const place=(x,y)=>{fab.style.right=fab.style.bottom='auto';fab.style.left=Math.max(0,Math.min(innerWidth-46,x))+'px';fab.style.top=Math.max(0,Math.min(innerHeight-46,y))+'px'};
if(pos)place(pos[0],pos[1]);
let dr=null;
fab.onpointerdown=e=>{dr={x:e.clientX,y:e.clientY,l:fab.offsetLeft,t:fab.offsetTop,m:0};fab.setPointerCapture(e.pointerId)};
fab.onpointermove=e=>{if(!dr)return;const dx=e.clientX-dr.x,dy=e.clientY-dr.y;if(dr.m||Math.hypot(dx,dy)>8){dr.m=1;place(dr.l+dx,dr.t+dy)}};
fab.onpointerup=()=>{if(!dr)return;if(dr.m)sv('gt_pos',[fab.offsetLeft,fab.offsetTop]);else{pan.hidden=!pan.hidden;if(!pan.hidden)draw()}dr=null};
function draw(){
  pan.textContent='';el('h3','','Archiwum usuniętych',pan);
  [['m','Wiadomości'],['p','Zdjęcia']].forEach(([k,x])=>{el('button','gt-b',x+': '+(GT.name(k)||'wybierz folder'),pan).onclick=()=>GT.pick(k)});
  el('h3','','Usunięte ('+del.length+')',pan);
  del.slice(-100).reverse().forEach(d=>el('div','gt-r',d.time+' · '+d.c+': '+d.w+' - '+d.t,pan));
  el('button','gt-b','Zamknij',pan).onclick=()=>pan.hidden=true;
}
window.__gtr=()=>{if(!pan.hidden)draw();scan()};
})();
