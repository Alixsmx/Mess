package com.glasstalk.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.getcapacitor.BridgeActivity;
import com.getcapacitor.BridgeWebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;

public class MainActivity extends BridgeActivity {
  private String kind = "m";
  private ActivityResultLauncher<Uri> picker;

  @Override
  public void onCreate(Bundle b) {
    picker = registerForActivityResult(new ActivityResultContracts.OpenDocumentTree(), uri -> {
      if (uri == null) return;
      getContentResolver().takePersistableUriPermission(uri,
          Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
      getPreferences(0).edit().putString(kind, uri.toString()).remove("mfile").apply();
      getBridge().getWebView().evaluateJavascript("window.__gtr&&window.__gtr()", null);
    });
    super.onCreate(b);
    WebView w = getBridge().getWebView();
    CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);
    w.addJavascriptInterface(this, "GT");
    String js = "";
    try (InputStream in = getAssets().open("gt.js")) {
      ByteArrayOutputStream bo = new ByteArrayOutputStream();
      byte[] buf = new byte[4096];
      int n;
      while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
      js = bo.toString("UTF-8");
    } catch (Exception e) { }
    final String code = js;
    getBridge().setWebViewClient(new BridgeWebViewClient(getBridge()) {
      @Override
      public void onPageFinished(WebView v, String u) {
        super.onPageFinished(v, u);
        v.evaluateJavascript(code, null);
      }
    });
  }

  private Uri dir(String k) {
    String s = getPreferences(0).getString(k, null);
    if (s == null) return null;
    Uri t = Uri.parse(s);
    return DocumentsContract.buildDocumentUriUsingTree(t, DocumentsContract.getTreeDocumentId(t));
  }

  private Uri create(String k, String mime, String name) throws IOException {
    Uri d = dir(k);
    Uri f = d == null ? null : DocumentsContract.createDocument(getContentResolver(), d, mime, name);
    if (f == null) throw new IOException("no folder");
    return f;
  }

  @JavascriptInterface
  public String name(String k) {
    String s = getPreferences(0).getString(k, null);
    if (s == null) return "";
    String n = String.valueOf(Uri.parse(s).getLastPathSegment());
    return n.substring(n.indexOf(':') + 1);
  }

  @JavascriptInterface
  public void pick(String k) {
    runOnUiThread(() -> { kind = k; picker.launch(null); });
  }

  @JavascriptInterface
  public void text(String line) {
    new Thread(() -> {
      try {
        String fu = getPreferences(0).getString("mfile", null);
        OutputStream o = null;
        if (fu != null) {
          try { o = getContentResolver().openOutputStream(Uri.parse(fu), "wa"); } catch (Exception e) { o = null; }
        }
        if (o == null) {
          Uri f = create("m", "text/plain", "usuniete_wiadomosci.txt");
          getPreferences(0).edit().putString("mfile", f.toString()).apply();
          o = getContentResolver().openOutputStream(f, "wa");
        }
        o.write((line + "\n").getBytes("UTF-8"));
        o.close();
      } catch (Exception e) { }
    }).start();
  }

  @JavascriptInterface
  public void url(String u, String file) {
    new Thread(() -> {
      try (InputStream in = new URL(u).openStream(); OutputStream o = getContentResolver().openOutputStream(create("p", "image/jpeg", file))) {
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
      } catch (Exception e) { }
    }).start();
  }

  @JavascriptInterface
  public void b64(String file, String data) {
    new Thread(() -> {
      try (OutputStream o = getContentResolver().openOutputStream(create("p", "image/jpeg", file))) {
        o.write(Base64.decode(data, Base64.DEFAULT));
      } catch (Exception e) { }
    }).start();
  }
}
