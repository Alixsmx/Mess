1. Wrzuc zawartosc do repo GitHub (z .github/workflows/build.yml, usun stary yml)
2. Actions -> Build GlassTalk APK -> Run workflow
3. Pobierz artefakt GlassTalk-APK
