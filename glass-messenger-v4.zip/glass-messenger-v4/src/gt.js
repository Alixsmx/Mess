(()=>{
if(window.__gt||!window.GT)return;window.__gt=1;
const LS=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}},sv=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch{}};
const el=(t,c,x,p)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;if(p)p.append(e);return e};
const vm=document.querySelector('meta[name=viewport]')||el('meta','',null,document.head);vm.name='viewport';vm.content='width=device-width,initial-scale=1';

/* ===== Liquid Glass ===== */
const V='--card-background,--card-background-flat,--surface-background,--web-wash,--wash,--comment-background,--messenger-card-background,--nav-bar-background,--nav-bar-background-gradient-wash,--secondary-button-background,--input-background';
el('style','',`
html,html[class]{color-scheme:dark;${V.split(',').map(v=>v+':rgba(255,255,255,.08)!important').join(';')};
--primary-text:#fff!important;--secondary-text:rgba(235,242,255,.75)!important;--primary-icon:#fff!important;--secondary-icon:rgba(235,242,255,.75)!important;--divider:rgba(255,255,255,.16)!important;--hover-overlay:rgba(255,255,255,.12)!important}
body{background:radial-gradient(60% 50% at 15% 10%,#3a7bff88,transparent),radial-gradient(50% 50% at 90% 85%,#b45cff77,transparent),linear-gradient(160deg,#07122b,#12285a) fixed!important}
[role=main],[role=navigation],[role=complementary],[role=banner]{backdrop-filter:blur(22px) saturate(1.9)!important;-webkit-backdrop-filter:blur(22px) saturate(1.9)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.4),0 12px 40px rgba(0,0,0,.28)!important;border-radius:22px}
.gt-f,.gt-p{position:fixed;z-index:2147483647;color:#fff;font:15px/1.4 system-ui,sans-serif;background:rgba(20,32,70,.55);backdrop-filter:blur(22px) saturate(1.9);-webkit-backdrop-filter:blur(22px) saturate(1.9);box-shadow:inset 0 1px 0 rgba(255,255,255,.5),0 10px 30px rgba(0,0,0,.35);border:1px solid rgba(255,255,255,.25)}
.gt-f{right:10px;bottom:90px;width:46px;height:46px;border-radius:50%;font-size:20px;cursor:pointer}
.gt-p{inset:8% 6%;border-radius:30px;padding:18px;overflow:auto;display:flex;flex-direction:column;gap:10px}
.gt-p[hidden]{display:none}
.gt-p h3{margin:6px 0 0;font-size:16px}
.gt-b{color:#fff;font:inherit;padding:12px 16px;border-radius:999px;border:1px solid rgba(255,255,255,.3);background:rgba(255,255,255,.16);cursor:pointer}
.gt-r{padding:8px 12px;border-radius:16px;background:rgba(255,255,255,.08);overflow-wrap:anywhere}
.gt-d{color:#ff9aa8;padding:4px 12px;font-size:14px;overflow-wrap:anywhere}`,document.head);

/* ===== archiwum usuniętych ===== */
const DEL=/(unsent (a|this) message|usun[a-zęąłó]*\s+wiadomość|cofn[a-zęąłó]*\s+wysłanie\s+wiadomości|wiadomość (została )?(usunięta|cofnięta))\.?$/i;
let store=LS('gt_s',{}),del=LS('gt_d',[]),ph=new Set(LS('gt_p',[])),seen=new WeakMap(),tm,last=0;
const txt=r=>{const a=[...r.querySelectorAll('[dir=auto]')].map(e=>e.innerText).join(' ').replace(/\s+/g,' ').trim();return a||''};
const isDel=t=>t.length<70&&DEL.test(t);
const flush=()=>{if(!GT.name('m'))return;let n=0;del.forEach(d=>{if(!d.f){d.f=1;n++;GT.text('['+d.time+'] '+d.c+' | '+d.t.replace(/\n/g,' '))}});if(n)sv('gt_d',del)};
function mark(r,o,c){
  el('div','gt-d','🗑 '+o,r);
  if(!del.some(d=>d.k===c+'|'+o)){del.push({k:c+'|'+o,c:(document.querySelector('[role=main] h2')||{}).innerText||c,t:o,time:new Date().toLocaleString('pl'),f:0});if(del.length>500)del.shift();sv('gt_d',del)}
}
function photos(){
  if(!GT.name('p'))return;
  document.querySelectorAll('[role=main] [role=row] img').forEach(i=>{
    const u=i.src||'',k=u.split('?')[0];
    if(i.naturalWidth<200||ph.has(k)||!/fbcdn|fbsbx/.test(u))return;
    ph.add(k);sv('gt_p',[...ph].slice(-3000));GT.url(u,'fb_'+Date.now()+'_'+ph.size+'.jpg');
  });
}
function scan(){
  const c=location.pathname,rs=[...document.querySelectorAll('[role=main] [role=row]')],T=rs.map(txt);
  rs.forEach((r,i)=>{
    const t=T[i];if(!t)return;
    const k=c+'\u0001'+(T[i-1]||'').slice(0,40)+'\u0001'+(T[i+1]||'').slice(0,40);
    if(!isDel(t)){seen.set(r,t);store[k]=t}
    else if(!r.querySelector('.gt-d')){
      const o=seen.get(r)||store[k];
      if(o&&!isDel(o))mark(r,o,c);
    }
  });
  const ks=Object.keys(store);if(ks.length>3000)ks.slice(0,ks.length-3000).forEach(k=>delete store[k]);
  if(Date.now()-last>5000){last=Date.now();sv('gt_s',store)}
  flush();photos();
}
new MutationObserver(()=>{clearTimeout(tm);tm=setTimeout(scan,700)}).observe(document.body,{childList:true,subtree:true,characterData:true});
document.addEventListener('visibilitychange',()=>sv('gt_s',store));
setTimeout(scan,1500);

/* ===== panel ===== */
const fab=el('button','gt-f','🗑',document.body),pan=el('div','gt-p',null,document.body);pan.hidden=true;
function draw(){
  pan.textContent='';el('h3','','Archiwum usuniętych',pan);
  [['m','Wiadomości'],['p','Zdjęcia']].forEach(([k,n])=>{el('button','gt-b',n+': '+(GT.name(k)||'wybierz folder'),pan).onclick=()=>GT.pick(k)});
  el('h3','','Usunięte wiadomości ('+del.length+')',pan);
  del.slice(-50).reverse().forEach(d=>el('div','gt-r',d.time+' · '+d.c+': '+d.t,pan));
  el('button','gt-b','Zamknij',pan).onclick=()=>pan.hidden=true;
}
fab.onclick=()=>{pan.hidden=!pan.hidden;if(!pan.hidden)draw()};
window.__gtr=()=>{if(!pan.hidden)draw();scan()};
})();
