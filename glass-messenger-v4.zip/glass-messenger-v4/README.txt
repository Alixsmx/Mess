1. Wrzuc zawartosc tego folderu do repo GitHub (z .github/workflows/build.yml)
2. Actions -> Build GlassTalk APK -> Run workflow
3. Pobierz artefakt GlassTalk-APK

src/ to zrodla (gt.js, MainActivity.java); yml ma je juz wbudowane. Zmiany w src wklej do yml.
